import sys
import tensorflow as tf
import numpy as np
new_model = tf.keras.models.load_model(r"C:\Users\Anish\Desktop\satellite imaging\web page\page\model_images\minor_\dataset and model\exp20Ckpt")

while(1):
    image = input()
    # print(image)
    img = tf.io.read_file('C:/Users/Anish/Desktop/satellite imaging/web page/retinaPrediction/images/'+image)
    img = tf.image.decode_jpeg(img,channels=3)
    img.set_shape((512,512,3))
    img = tf.cast(img , tf.float32) /255.0
    data = []
    data.append(img)
    data = np.array(data)

    predictions = new_model.predict(data)
    predictions = tf.nn.softmax(predictions)
    preArgMax=tf.argmax(predictions,axis=-1 ).numpy()
    print(preArgMax[0])
